﻿using Microsoft.Azure.Cosmos;

string endpoint = "https://dbacc1352.documents.azure.com:443/";
string key = "qO1bWicf8TyDr98MlYIeaUF4zZa9N27eqDWHRjc8T5riLqKnIFV6QgFWQ9CknDvlqZD1ylNArON7ACDbNuVy8A==";
string databaseName = "orderdb";
string containerName = "Orders";


await CreateItem();

async Task CreateItem()
{
    CosmosClient cosmosClient;
    cosmosClient = new CosmosClient(endpoint, key);

    Container container = cosmosClient.GetContainer(databaseName, containerName);

    dynamic orderItem =
        new
        {
            id = Guid.NewGuid().ToString(),
            orderId = "O1",
            category = "Laptop"
        };

    await container.CreateItemAsync(orderItem, null, new ItemRequestOptions { PreTriggers = new List<string> { "validateItem" } });

    Console.WriteLine("Item has been inserted");

}