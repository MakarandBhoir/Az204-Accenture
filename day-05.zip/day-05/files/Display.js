function Display() {
    var response = getContext().getResponse();
    response.setBody('This is a stored procedure');
}