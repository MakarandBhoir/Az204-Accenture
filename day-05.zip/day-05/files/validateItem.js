function validateItem() {
    var context = getContext();
    var request = context.getRequest();
    var item = request.getBody();

    if (!("price" in item)) {
        item["price"] = 0;
    }

    request.setBody(item);
}