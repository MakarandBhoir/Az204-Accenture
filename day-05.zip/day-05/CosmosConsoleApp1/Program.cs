﻿using CosmosConsoleApp1;
using Microsoft.Azure.Cosmos;

string connection = "AccountEndpoint=https://accenture1622.documents.azure.com:443/;AccountKey=2n8vKDVKgufHAQWlQegahg3SE5GFzhZKt4xqHak1cdsF0RTWaNBLYe26GlyIRArQ0AFZV8oICIuFACDb4MsxBw==;";
string orderdb = "orderdb";
string containerName = "orders";

CosmosClient client = new CosmosClient(connection);

/*await client.CreateDatabaseAsync(orderdb);
Console.WriteLine(orderdb+ " is created.");

Database database = client.GetDatabase(orderdb);
await database.CreateContainerAsync(containerName, "/category");
Console.WriteLine(containerName + " is created.");*/

/*await AddItem("01", "Mobiles", 2, 250);
await AddItem("02", "Laptop", 1, 350);
await AddItem("03", "Desktop", 1, 200);
await AddItem("04", "Mobiles", 1, 150);*/

/*async Task AddItem(string orderId, string category, int quantity, double price)
{
    Database database = client.GetDatabase(orderdb);
    Container container = database.GetContainer(containerName);

    Order order = new Order()
    {
        id = Guid.NewGuid().ToString(),
        orderId = orderId,
        category = category,
        quantity = quantity,
        price = price
    };

    ItemResponse<Order> response = await container.CreateItemAsync<Order>(order, new PartitionKey(category));

    Console.WriteLine("Data added to container.");
}*/

//await AddItemWithoutPrice("05", "Laptop", 1);
//await AddItemWithoutPrice("06", "Desktop", 1);
await AddItemWithoutPrice("07", "Desktop", 1);

async Task AddItemWithoutPrice(string orderId, string category, int quantity)
{
    Database database = client.GetDatabase(orderdb);
    Container container = database.GetContainer(containerName);

    Order order = new Order()
    {
        id = Guid.NewGuid().ToString(),
        orderId = orderId,
        category = category,
        quantity = quantity
    };

    ItemResponse<Order> response = await container.CreateItemAsync<Order>(order, new PartitionKey(category));

    //await container.CreateItemAsync(order, null, new ItemRequestOptions { PreTriggers = new List<string> { "validateItem" } });

    Console.WriteLine("Data added to container.");
}