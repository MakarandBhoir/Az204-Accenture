﻿
using Microsoft.Azure.Cosmos;

string endpoint = "";
string key = "";
string databaseName = "orderdb";
string containerName = "Orders";

CosmosClient client = new CosmosClient(endpoint, key);

Container container = client.GetContainer(databaseName, containerName);

await CallStoredProcedure();

async Task CallStoredProcedure()
{
    var result = await container.Scripts.ExecuteStoredProcedureAsync<string>("Display", new PartitionKey(""), null);
    Console.WriteLine(result);
}

