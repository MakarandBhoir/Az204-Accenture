﻿
using Azure.Identity;
using Azure.Storage.Blobs;

string tenantId = "ae6cba77-f65c-49f3-b41d-37f9945b7135";
string clientId = "f938fe7e-70b5-4ef4-8182-d7506954eb22";
string clientSecret = "reg8Q~ER-wAFz8S7hmEOJpJ2QwNxaTYV6h63Iasn";



string blobURI = "https://accenturestore.blob.core.windows.net/data/08.png";
string filePath = "D:\\Training\\Accenture\\DEPR\\AZ-204\\batch-3\\new.png";

ClientSecretCredential clientCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);

BlobClient blobClient = new BlobClient(new Uri(blobURI), clientCredential);

//await blobClient.UploadAsync(filePath);

await blobClient.DownloadToAsync(filePath);

Console.WriteLine("The blob is downloaded");