﻿using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Newtonsoft.Json;
using StorageQueue;

string connectionString = "DefaultEndpointsProtocol=https;AccountName=accentureaccount0952;AccountKey=kQhYjgCz8qVJ1SMsuI5KTFcnmdyUQqXtSQoxkNDbNdWcKiWQB4d5uU3WnJoXaqYcowGs2BQ1zyDX+ASt0vjbFg==;EndpointSuffix=core.windows.net";
string queueName = "queue1";

/*await SendMessage("O01", 50);
await SendMessage("O02", 40);
await SendMessage("O03", 30);
await SendMessage("O04", 20);
await SendMessage("O05", 10);*/


await PeekMessages();

async Task SendMessage(string orderid,int quantity)
{
    QueueClient queueClient = new QueueClient(connectionString, queueName);
    if (queueClient.Exists())
    {
       Order order=new Order {OrderID = orderid,Quantity=quantity};
       await queueClient.SendMessageAsync(JsonConvert.SerializeObject(order));
       Console.WriteLine("Order Id {0} sent", orderid);
    }
}

async Task PeekMessages()
{
    QueueClient queueClient = new QueueClient(connectionString, queueName);
    int maxMessages = 10;

    if (queueClient.Exists())
    {
        PeekedMessage[] peekedMessages = await queueClient.PeekMessagesAsync(maxMessages);
        Console.WriteLine("The orders in the queue");
        foreach(var message in peekedMessages)
        {
            Order order = JsonConvert.DeserializeObject<Order>(message.Body.ToString());
            Console.WriteLine("Order Id {0}",order.OrderID);
            Console.WriteLine("Order Quantity {0}",order.Quantity);
            //Console.WriteLine(message.Body.ToString());
        }
    }
}

