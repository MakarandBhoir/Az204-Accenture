﻿//sender connection string:
using Azure.Messaging.ServiceBus;

const string connectionString = "Endpoint=sb://accenture1616.servicebus.windows.net/;SharedAccessKeyName=send-policy;SharedAccessKey=Qs1kESyEeTeFBBQoSrXJvbTqWFkN7IIEp+ASbFrYn38=;EntityPath=queue1";
const string queueName = "queue1";
ServiceBusClient? client = default;
ServiceBusSender? sender = default;
const int numOfMessages = 5;
client = new ServiceBusClient(connectionString);
sender = client.CreateSender(queueName);

using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();

for (int i = 1; i <= numOfMessages; i++)
{
    ServiceBusMessage message = new ServiceBusMessage($"Message {i}");
    message.MessageId = i.ToString();

    if (!messageBatch.TryAddMessage(message))
    {
        throw new Exception($"The message {i} is too large to fit in the batch.");
    }
}
try
{
    await sender.SendMessagesAsync(messageBatch);
    Console.WriteLine($"A batch of {numOfMessages} messages has been published to the queue.");
}
finally
{
    await sender.DisposeAsync();
    await client.DisposeAsync();
}