﻿namespace ProductCatalog.Domain
{
    public class Class1
    {

    }
}
