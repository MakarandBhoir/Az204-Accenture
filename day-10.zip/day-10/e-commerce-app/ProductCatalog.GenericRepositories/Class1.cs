﻿namespace ProductCatalog.GenericRepositories
{
    public class Class1
    {

    }
}
