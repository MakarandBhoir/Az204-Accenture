﻿using Microsoft.EntityFrameworkCore;
using ProductCatalog.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.EFRepositories
{
    public class ProductCatalogDbContext : DbContext
    {
        public ProductCatalogDbContext(DbContextOptions<ProductCatalogDbContext> options)
            : base(options)
        {
        }

        public DbSet<CatalogType> CatalogType { get; set; } = default!;
        public DbSet<CatalogItem> CatalogItem { get; set; } = default!;
        public DbSet<CatalogBrand> CatalogBrand { get; set; } = default!;
    }

}
