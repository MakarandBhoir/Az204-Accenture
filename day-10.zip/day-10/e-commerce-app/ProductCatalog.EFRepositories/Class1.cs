﻿namespace ProductCatalog.EFRepositories
{
    public class Class1
    {

    }
}
