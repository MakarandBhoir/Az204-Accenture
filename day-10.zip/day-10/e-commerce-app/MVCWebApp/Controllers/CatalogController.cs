﻿using Microsoft.AspNetCore.Mvc;
using MVCwebApp.Models;
using MVCWebApp.Services.MVCwebApp.Services;

namespace MVCWebApp.Controllers
{
    public class CatalogController : Controller
    {
        ICatalogServcie _catalogService;
        public CatalogController(ICatalogServcie catalogService)
        {
            _catalogService = catalogService;
        }

        public async Task<IActionResult> Index()
        {
            var items = await _catalogService.GetCatalogItems(null, null);
            return View(items);
        }

        public async Task<ActionResult> Details(int id)
        {
            CatalogItem item = await _catalogService.GetItemDetails(id);
            return View(item);
        }

        public async Task<ActionResult> Edit(int id)
        {
            var item = await _catalogService.GetItemDetails(id);
            return View(item);
        }

        [HttpPost]
        public async Task<ActionResult> Edit(int id, CatalogItem item)
        {
            await _catalogService.Update(item);
            return RedirectToAction("Index");
        }

    }
}
