﻿using Microsoft.AspNetCore.Mvc;
using MVCWebApp.Services.MVCwebApp.Services;
using MVCWebApp.Services;
using MVCwebApp.Models;

namespace MVCWebApp.Controllers
{
    public class BasketController : Controller
    {
        IBasketService _basketService;
        ICatalogServcie _catalogService;
        public BasketController(IBasketService basketService, ICatalogServcie catalogService)
        {
            _basketService = basketService;
            _catalogService = catalogService;
        }
        public async Task<IActionResult> Index()
        {
            var userId = "userWalmart";
            var basket = await _basketService.GetBasket(userId);
            return View(basket);
            
        }
        public async Task<IActionResult> AddToBasket(int id)
        {
            CatalogItem catItem = await _catalogService.GetItemDetails(id);
            if (catItem != null)
            {
                var userId = "userWalmart";
                var product = new BasketItem()
                {
                    Id = Guid.NewGuid().ToString(),
                    Quantity = 1,
                    ProductName = catItem.Name,
                    PictureUrl = catItem.PictureFileName,
                    UnitPrice = catItem.Price,
                    ProductId = catItem.Id
                };
                await _basketService.AddItemToBasket(userId, product);
            }
            return RedirectToAction("Index", "Catalog");
        }

    }
}
