﻿namespace MVCWebApp.Services
{
    using global::MVCwebApp.Models;
    using Microsoft.AspNetCore.Mvc.Rendering;
      using Newtonsoft.Json;

    namespace MVCwebApp.Services
    {
        public interface ICatalogServcie
        {
            Task<IEnumerable<CatalogItem>> GetCatalogItems(int? brand, int? type);
            Task<CatalogItem> GetItemDetails(int id);
            Task<IEnumerable<SelectListItem>> GetBrands();
            Task<IEnumerable<SelectListItem>> GetTypes();

            Task Update(CatalogItem item);
        }
        public class CatalogService : ICatalogServcie
        {
            private readonly string _remoteServiceBaseUrl;
            public CatalogService(IConfiguration config)
            {
                _remoteServiceBaseUrl = config["CatalogUrl"];
            }
            public async Task<IEnumerable<CatalogItem>> GetCatalogItems(int? brand, int? type)
            {
                var client = new HttpClient();
                var result = await client.GetAsync(_remoteServiceBaseUrl + "/api/CatalogItems/");
                var dataString = await result.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<IEnumerable<CatalogItem>>(dataString);
            }
            public async Task<CatalogItem> GetItemDetails(int id)
            {
                HttpClient client = new HttpClient();
                string strjson = await client.GetStringAsync(_remoteServiceBaseUrl + "/api/CatalogItems/" + id);
                CatalogItem items = JsonConvert.DeserializeObject<CatalogItem>(strjson);
                return items;
            }
            public async Task<IEnumerable<SelectListItem>> GetBrands()
            {
                var client = new HttpClient();
                var result = await client.GetAsync(_remoteServiceBaseUrl + "/api/CatalogBrand/");
                var dataString = await result.Content.ReadAsStringAsync();
                var catalogBrands = JsonConvert.DeserializeObject<IEnumerable<CatalogItem>>(dataString);
                return new SelectList(catalogBrands, "Id", "Brand");
            }
            public async Task<IEnumerable<SelectListItem>> GetTypes()
            {
                var client = new HttpClient();
                var result = await client.GetAsync(_remoteServiceBaseUrl + "/api/CatalogType/");
                var dataString = await result.Content.ReadAsStringAsync();
                var catalogTypes = JsonConvert.DeserializeObject<IEnumerable<CatalogItem>>(dataString);
                return new SelectList(catalogTypes, "Id", "Type");
            }

            public async Task Update(CatalogItem item)
            {
                var client = new HttpClient();
                HttpContent content = new StringContent(JsonConvert.SerializeObject(item), System.Text.Encoding.UTF8,
               "application/json");
                var result = await client.PutAsync(_remoteServiceBaseUrl + "/api/CatalogItems/" + item.Id, content);
                // result.EnsureSuccessStatusCode();
            }
        }
    }

}
