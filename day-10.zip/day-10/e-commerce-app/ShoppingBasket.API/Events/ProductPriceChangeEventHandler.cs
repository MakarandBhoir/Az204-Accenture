﻿using EventBusLib.Abstractions;
using ShoppingBasket.API.Model;
using ShoppingBasket.API.Repository;

namespace ShoppingBasket.API.Events
{

    public class ProductChangedIntegrationEventHandlers :
IIntegrationEventHandler<ProductPriceUpdateIntegrationEvent>
    {
        IBasketRepository _repository;
        public ProductChangedIntegrationEventHandlers(IBasketRepository repo)
        {
            _repository = repo;
        }
        public async void Handle(ProductPriceUpdateIntegrationEvent evt)
        {
            var userIds = _repository.GetBuyers();
            foreach (var id in userIds)
            {
                var basket = await _repository.GetBasketAsync(id);
                var product = basket.Items.Where(product => product.ProductId == evt.ProductId).FirstOrDefault();
                if (product != null)
                {
                    product.UnitPrice = evt.NewPrice;
                }
                await _repository.UpdateBasketAsync(basket);


            }
        }
    }
}
