﻿using EventBusLib.Abstractions;
using ProductCatalog.BusinessObjects.Events;
using ProductCatalog.Domain;
using ProductCatalog.GenericRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.BusinessObjects
{
    public class CatalogItemBO : ICatalogItemBO
    {
        ICatalogItemRepository _repository;
        IEventBus _bus;
        public CatalogItemBO(ICatalogItemRepository repository,IEventBus bus)
        {
            _repository = repository;
            _bus = bus;
        }
        public async Task<CatalogItem> Add(CatalogItem item)
        {
            await _repository.Add(item);
            return item;
        }
        public async Task Delete(int id)
        {
            await _repository.Delete(id);
        }
        public async Task<CatalogItem> GetCatalogItemDetails(int id)
        {
            return await _repository.GetById(id);
        }
        public async Task<IEnumerable<CatalogItem>> GetCatalogItems()
        {
            return await _repository.GetAll();
        }
        public async Task Update(CatalogItem productToUpdate)
        {
            var catalogItem = await _repository.GetById(productToUpdate.Id);
            var oldPrice = catalogItem.Price;
            var raiseProductPriceUpdatedEvent = oldPrice != productToUpdate.Price;
            //Copy Data from Old Object to New Object using Reflection
            foreach (var pi in productToUpdate.GetType().GetProperties())
            {
                pi.SetValue(catalogItem, pi.GetValue(productToUpdate));
            }
            await _repository.Update(catalogItem);
            if (raiseProductPriceUpdatedEvent)//Integration events
            {
               var priceChangedEvent = new ProductPriceUpdateIntegrationEvent(productToUpdate.Id,
                productToUpdate.Price, oldPrice);
                await _bus.Publish(priceChangedEvent);
            }
        }
    }

}
