﻿namespace ProductCatalog.BusinessObjects
{
    public class Class1
    {

    }
}
