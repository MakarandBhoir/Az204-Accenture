﻿namespace EventBusLib
{
    public class Class1
    {

    }
}
