﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventBusLib.Abstractions
{
    public interface IEventBus
    {
        Task Publish<T>(T e) where T : EshopIntegrationEvent;

        void Subscribe<T, TH>(TH eventHandler)
        where T : EshopIntegrationEvent
        where TH : IIntegrationEventHandler<T>;
    }
}
