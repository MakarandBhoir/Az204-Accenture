﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHubSendData
{
    public class Device
    {
        public string deviceId { get; set; }

        public float temperature { get; set; }
    }
}
