﻿using StackExchange.Redis;

string connectionString = "accenture.redis.cache.windows.net:6380,password=A4svGrWJyIKWU4k6aMrNxyQy03x0gC8B0AzCaNqLFvA=,ssl=True,abortConnect=False";

ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(connectionString);

SetCacheData();
GetCacheData();

void SetCacheData()
{
    IDatabase database=redis.GetDatabase();

    database.StringSet("top:3:products", "Mobile, TV, Shirt");
    database.KeyExpire("top:3:products", new TimeSpan(0, 1, 0));

    Console.WriteLine("Cache data set");
}

void GetCacheData()
{
    IDatabase database = redis.GetDatabase();
    if (database.KeyExists("top:3:products"))
        Console.WriteLine(database.StringGet("top:3:products"));
    else
        Console.WriteLine("key does not exist");

}