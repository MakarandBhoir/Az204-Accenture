﻿using Azure.Storage.Blobs;

string connection = "DefaultEndpointsProtocol=https;AccountName=accenturestore;AccountKey=VmxuGe4JWq/lYSQR4GGavciKruM284o5rkf0VzB5l4xDHuadgpPtwfX3SpbgQLO7MZwH5A+scMLe+AStIhmdIQ==;EndpointSuffix=core.windows.net";
string container = "code-data3";
BlobServiceClient blobServiceClient = new BlobServiceClient(connection);

await blobServiceClient.CreateBlobContainerAsync(container);

Console.WriteLine(container+" is created.");


